# Thần Thức Online 1.4.58 — Khôi phục URL kết nối

- Thay URL Quick Tunnel cũ bằng `https://disclaimers-taste-element-difficulty.trycloudflare.com`.
- Giữ nguyên đường dẫn Socket.IO `/world/socket.io` và namespace `/world`.
- Đồng bộ `CURRENT` và `mod.yaml` lên 1.4.58 cho nút **Kiểm tra cập nhật**.
- Không chỉnh logic Tỉ thí, Anti-Cheat, Tổ đội, Phân Hồn, danh sách online.
- Đã kiểm tra `node --check`, build và diff chỉ đúng 2 vị trí trong main.js.
- **Chưa kiểm thử online thực tế và chưa đẩy GitHub.**
- Quick Tunnel không cố định, URL này có thể lại hết hạn.

Để phát hành qua nút Kiểm tra cập nhật, đẩy **cả `main.js` và `mod.yaml`** từ gói nguồn lên nhánh main của repository `hienadonis-source/vktt-than-thuc-online`. Có thể đẩy thêm `Thần Thức Online.zip` để đồng bộ file phát hành.
