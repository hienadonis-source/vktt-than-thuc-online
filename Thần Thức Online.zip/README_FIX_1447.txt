1.4.47: Hoan thanh khoi tao UI PvP truoc khi xu ly duel:start; hien thi ly do dong phong; khong thay doi combat/anti-cheat.
